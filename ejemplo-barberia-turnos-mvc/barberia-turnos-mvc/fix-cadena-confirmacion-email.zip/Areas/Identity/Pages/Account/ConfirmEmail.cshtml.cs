#nullable disable

using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.WebUtilities;
using barberia_turnos_mvc.Services;

namespace barberia_turnos_mvc.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class ConfirmEmailModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ICurrentBarberiaService _currentBarberia;

        public ConfirmEmailModel(UserManager<ApplicationUser> userManager, ICurrentBarberiaService currentBarberia)
        {
            _userManager = userManager;
            _currentBarberia = currentBarberia;
        }

        [TempData]
        public string StatusMessage { get; set; }

        public bool Exito { get; set; }

        public string BarberiaSlug { get; set; }

        public async Task<IActionResult> OnGetAsync(string userId, string code)
        {
            BarberiaSlug = _currentBarberia.Barberia?.Slug;

            if (userId == null || code == null)
            {
                return RedirectToPage("/Index");
            }

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                StatusMessage = $"No se pudo cargar el usuario con Id '{userId}'.";
                Exito = false;
                return Page();
            }

            code = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code));
            var result = await _userManager.ConfirmEmailAsync(user, code);

            Exito = result.Succeeded;
            StatusMessage = result.Succeeded
                ? "¡Gracias por confirmar tu email!"
                : "Hubo un error al confirmar tu email. El link puede haber vencido.";

            return Page();
        }
    }
}
