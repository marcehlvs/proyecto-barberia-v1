#nullable disable

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using barberia_turnos_mvc.Services;

namespace barberia_turnos_mvc.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class RegisterConfirmationModel : PageModel
    {
        private readonly ICurrentBarberiaService _currentBarberia;

        public RegisterConfirmationModel(ICurrentBarberiaService currentBarberia)
        {
            _currentBarberia = currentBarberia;
        }

        public string Email { get; set; }
        public string BarberiaSlug { get; set; }

        public void OnGet(string email, string returnUrl = null)
        {
            Email = email;
            BarberiaSlug = _currentBarberia.Barberia?.Slug;
        }
    }
}
